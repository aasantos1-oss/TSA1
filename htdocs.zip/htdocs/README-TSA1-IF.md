# TSA1: Tasks for Today Management System — InfinityFree Deployment Guide

The `htdocs/` folder inside this ZIP already has the correct flat-layout structure.

## Upload Instructions

1. **Upload the `htdocs/` folder ZIP** to InfinityFree File Manager
2. **Extract** the ZIP (it extracts into `htdocs/`)
3. **Import the database** (via IF phpMyAdmin)

| File | Purpose |
|---|---|
| `index_if.php` | IF flat-layout front controller (copy to `htdocs/index.php`) |
| `.htaccess` | Root-level IF rewrite rules (copy to `htdocs/.htaccess`) |
| `.env.production` | Pre-configured `.env` for IF (rename to `.env`) |
| `tsa1_store.sql` | Database seed file (import via phpMyAdmin) |
| `README-TSA1-IF.md` | This deployment guide |

## Quick Upload Steps

1. **Prepare files** (do this on your PC):
   - Copy `deploy/index_if.php` → rename to `index.php`
   - Copy `deploy/.htaccess` → copy as-is
   - Copy `.env.production` → rename to `.env`
   - Edit `.env` → fill in your IF MySQL password

2. **Via InfinityFree File Manager** (not FTP — FTP is blocked by IF's anti-bot):
   - Upload `index.php` to `htdocs/`
   - Upload `.htaccess` to `htdocs/`
   - Upload `.env` to `htdocs/`
   - Upload `app/` folder to `htdocs/app/`
   - Upload `system/` folder to `htdocs/system/`
   - Upload `vendor/` folder to `htdocs/vendor/`
   - Upload `writable/` folder to `htdocs/writable/`

3. **Import database** (via IF phpMyAdmin):
   - Go to IF control panel → MySQL → phpMyAdmin
   - Select your database
   - Import `database/tsa1_store.sql`

4. **Set folder permissions**:
   - `writable/session/` → 755
   - `writable/cache/` → 755
   - `writable/logs/` → 755

5. **Test**: Visit `https://aasantostechnical.is-great.net/`

## If You See the Anti-Bot Page

IF's anti-bot JS challenge blocks automated HTTP requests. To bypass:
- Open the site in your **browser** (Chrome/Firefox) — it will solve the JS automatically
- Or visit: `https://aasantostechnical.is-great.net/?i=1` with a browser
- The site works correctly once the JS challenge is solved

## Files NOT needed on IF

- `spark` (CLI tool — local only)
- `tests/` directory
- `phpunit.xml.dist`
- `.git/`
- `.env.production` (you already copied it to `.env`)
