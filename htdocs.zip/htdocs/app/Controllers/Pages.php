<?php

namespace App\Controllers;

use App\Models\TaskModel;
use App\Models\UserModel;

class Pages extends BaseController
{
    public function index()
    {
        $model  = new TaskModel();
        $today  = date('Y-m-d');
        $tasks  = $model->getByDate($today);

        $data = [
            'title'      => 'Tasks for Today',
            'heading'    => 'Tasks for Today',
            'today'      => $today,
            'tasks'      => $tasks,
            'taskCount'  => count($tasks),
        ];

        return view('pages/home', $data);
    }

    public function profile()
    {
        $model = new UserModel();
        $user  = $model->getDemoUser();

        $data = [
            'title'   => 'Profile',
            'heading'  => 'User Profile',
            'user'     => $user,
        ];

        return view('pages/profile', $data);
    }

    public function about()
    {
        $data = [
            'title'    => 'About',
            'heading'  => 'About This Application',
            'developer' => 'Adrian Axel V. Santos',
            'studentId' => 'Your Student ID Here',
            'message'  => 'This is a Tasks for Today Management System built with CodeIgniter 4.',
        ];

        return view('pages/about', $data);
    }
}
