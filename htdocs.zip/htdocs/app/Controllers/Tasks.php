<?php

namespace App\Controllers;

use App\Models\TaskModel;

class Tasks extends BaseController
{
    public function index()
    {
        $model = new TaskModel();
        $tasks = $model->getAllSorted();

        $data = [
            'title'  => 'All Tasks',
            'heading' => 'Task List',
            'tasks'  => $tasks,
            'taskCount' => count($tasks),
        ];

        return view('tasks/index', $data);
    }
}
