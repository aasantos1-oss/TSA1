<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table      = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = ['username', 'full_name', 'email', 'created_at'];
    protected $useTimestamps = false;

    /**
     * Get the single demo user record.
     */
    public function getDemoUser()
    {
        return $this->orderBy('id', 'ASC')->first();
    }
}
