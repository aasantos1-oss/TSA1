<?php

namespace App\Models;

use CodeIgniter\Model;

class TaskModel extends Model
{
    protected $table      = 'tasks';
    protected $primaryKey = 'id';
    protected $allowedFields = ['title', 'status', 'task_date', 'created_at'];
    protected $useTimestamps = false;

    /**
     * Get tasks for a specific date (e.g., today).
     */
    public function getByDate(string $date)
    {
        return $this->where('task_date', $date)
                    ->orderBy('created_at', 'DESC')
                    ->findAll();
    }

    /**
     * Get all tasks ordered by task_date.
     */
    public function getAllSorted()
    {
        return $this->orderBy('task_date', 'DESC')
                    ->findAll();
    }
}
