<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Pages::index');       // Welcome page (today's tasks)
$routes->get('/tasks', 'Tasks::index');   // Full task list
$routes->get('/profile', 'Pages::profile'); // Profile page
$routes->get('/about', 'Pages::about');    // About page
