<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 2rem; }
        h1 { color: #333; }
        nav { margin: 1rem 0; }
        nav a { margin-right: 1rem; }
        .profile-card { border: 1px solid #ddd; padding: 1.5rem; border-radius: 8px; max-width: 500px; }
        .profile-card p { margin: 0.3rem 0; }
        .label { font-weight: bold; }
    </style>
</head>
<body>
    <h1><?= esc($heading) ?></h1>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a>
        <a href="<?= base_url('tasks') ?>">All Tasks</a>
        <a href="<?= base_url('profile') ?>">Profile</a>
        <a href="<?= base_url('about') ?>">About</a>
    </nav>

    <?php if ($user): ?>
    <div class="profile-card">
        <p><span class="label">Username:</span> <?= esc($user['username']) ?></p>
        <p><span class="label">Full Name:</span> <?= esc($user['full_name']) ?></p>
        <p><span class="label">Email:</span> <?= esc($user['email']) ?></p>
        <p><span class="label">Account Created:</span> <?= esc($user['created_at']) ?></p>
    </div>
    <?php else: ?>
    <p>No user profile found.</p>
    <?php endif; ?>

</body>
</html>
