<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 2rem; }
        h1 { color: #333; }
        nav { margin: 1rem 0; }
        nav a { margin-right: 1rem; }
        .about-box { border: 1px solid #ddd; padding: 1.5rem; border-radius: 8px; }
    </style>
</head>
<body>
    <h1><?= esc($heading) ?></h1>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a>
        <a href="<?= base_url('tasks') ?>">All Tasks</a>
        <a href="<?= base_url('profile') ?>">Profile</a>
        <a href="<?= base_url('about') ?>">About</a>
    </nav>

    <div class="about-box">
        <p><strong>Developer:</strong> <?= esc($developer) ?></p>
        <p><strong>Student ID:</strong> <?= esc($studentId) ?></p>
        <p><?= esc($message) ?></p>
    </div>

</body>
</html>