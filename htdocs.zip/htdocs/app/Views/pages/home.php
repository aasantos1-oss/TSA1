<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
    <style>
        body { font-family: Arial, sans-serif; margin: 2rem; }
        h1 { color: #333; }
        nav { margin: 1rem 0; }
        nav a { margin-right: 1rem; }
        table { border-collapse: collapse; width: 100%; margin-top: 1rem; }
        th, td { border: 1px solid #ddd; padding: 0.5rem; text-align: left; }
        th { background-color: #f4f4f4; }
        .pending { color: #e74c3c; }
        .completed { color: #27ae60; text-decoration: line-through; }
        .empty-msg { color: #999; font-style: italic; margin-top: 1rem; }
    </style>
</head>
<body>
    <h1><?= esc($heading) ?></h1>
    <p>Today's date: <strong><?= esc($today) ?></strong></p>
    <p>Total tasks for today: <strong><?= esc($taskCount) ?></strong></p>

    <nav>
        <a href="<?= base_url('/') ?>">Home</a>
        <a href="<?= base_url('tasks') ?>">All Tasks</a>
        <a href="<?= base_url('profile') ?>">Profile</a>
        <a href="<?= base_url('about') ?>">About</a>
    </nav>

    <?php if ($taskCount > 0): ?>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Task</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($tasks as $task): ?>
            <tr>
                <td><?= esc($task['id']) ?></td>
                <td><?= esc($task['title']) ?></td>
                <td class="<?= $task['status'] === 'completed' ? 'completed' : 'pending' ?>">
                    <?= esc($task['status']) ?>
                </td>
                <td><?= esc($task['task_date']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
    <p class="empty-msg">No tasks for today. Have a productive day!</p>
    <?php endif; ?>

</body>
</html>
